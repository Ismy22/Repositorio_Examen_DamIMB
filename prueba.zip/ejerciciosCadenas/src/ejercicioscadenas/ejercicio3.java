/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicioscadenas;

import java.util.Scanner;

/**
 *
 * 3.	Crea un programa que pida por teclado tres cadenas de texto: 
 * nombre y dos apellidos. Luego mostrará un código de usuario (en mayúsculas) 
 * formado por la concatenación de las tres primeras letras de cada uno de ellos. 
 * Por ejemplo si se introduce “Lionel”, “Tarazón” y “Alcocer” mostrará “LIOTARALC”.
 * 
 * @author IsmaelMB
 */
public class ejercicio3 {

  
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        System.out.println("Dime tu nombre: ");
        String nombre=teclado.nextLine();
        System.out.println("Dime tu primer apellido: ");
        String apellido1=teclado.nextLine();
        System.out.println("Dime tu segundo apellido: ");
        String apellido2=teclado.nextLine();
        
        String iniciales=(nombre.substring(0,3)+apellido1.substring(0, 3)+apellido2.substring(0, 3)).toUpperCase();
        
        System.out.println(iniciales);
        
        
    }
    
}
