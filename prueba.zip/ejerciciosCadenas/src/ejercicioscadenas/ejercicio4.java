/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicioscadenas;

import java.util.Scanner;

/**
 *
 * 4.	Crea un programa que muestre por pantalla cuantas vocales de cada tipo 
 * hay (cuantas ‘a’, cuantas ‘e’, etc.) en una frase introducida por teclado. 
 * No se debe diferenciar entre mayúsculas y minúsculas. Por ejemplo dada la 
 * frase “Mi mama me mima” dirá que hay:
 
    Nº de A's: 3
    Nº de E's: 1
    Nº de I's: 2
    Nº de O's: 0
    Nº de U's: 0

 * 
 * 
 * @author IsmaelMB
 */
public class ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        System.out.println("Dime una frase: ");
        String frase=teclado.nextLine();
        frase=frase.toUpperCase();
        int num_a=0;
        int num_e=0;
        int num_i=0;
        int num_o=0;
        int num_u=0;
        for (int i=0;i<frase.length();i++){
            if (frase.charAt(i)=='A'){
                num_a++;
            }
            else if (frase.charAt(i)=='E'){
                num_e++;
            }
            else if (frase.charAt(i)=='I'){
                num_i++;
            }
            else if (frase.charAt(i)=='O'){
                num_o++;
            }
            else if (frase.charAt(i)=='U'){
                num_u++;
            } 
        }
        if (num_a == 0 && num_e==0 && num_i==0 && num_o==0 && num_u==0){
            System.out.println("Esta frase no contiene vocales\n");
        }
        else{
            System.out.println("Nº de A's: "+num_a);
            System.out.println("Nº de E's: "+num_e);
            System.out.println("Nº de I's: "+num_i);
            System.out.println("Nº de O's: "+num_o);
            System.out.println("Nº de U's: "+num_u);
        }
        
    }
    
}
