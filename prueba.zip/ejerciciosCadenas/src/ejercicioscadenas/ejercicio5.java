/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicioscadenas;

import java.util.Scanner;

/**
 *
  5.	Realiza un programa que lea una frase por teclado e indique si la frase
  es un palíndromo o no (ignorando espacios y sin diferenciar entre mayúsculas y minúsculas). 
  Supondremos que el usuario solo introducirá letras y espacios (ni comas, ni puntos, ni acentos, etc.). 
  Un palíndromo es un texto que se lee igual de izquierda a derecha que de derecha a izquierda. Por ejemplo:
  
    Amigo no gima
    Dabale arroz a la zorra el abad
    Amo la pacífica paloma
    A man a plan a canal Panama

 * 
 * @author IsmaelMB
 */
public class ejercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        System.out.println("Dime una frase: ");
        String frase=teclado.nextLine();
        frase=frase.replace(" ", "");
        StringBuilder frase2 = new StringBuilder(frase);
        String palindromo = (frase2.reverse().toString().trim());
        //System.out.println(palindromo);
        //System.out.println(frase);
        
        if (frase.equalsIgnoreCase(palindromo)){
            System.out.println("La frase es un palídromo");
        }
        else{
            System.out.println("La frase no es un palíndromo");
        }
        
        
        
    }
    
}
