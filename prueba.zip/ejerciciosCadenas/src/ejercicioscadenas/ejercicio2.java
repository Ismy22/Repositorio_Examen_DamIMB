/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicioscadenas;

import java.util.Scanner;

/**
 *
 * 2. Crea un programa que pida dos cadenas de texto por teclado y luego 
 * indique si son iguales, además de si son iguales sin diferenciar entre 
 * mayúsculas y minúsculas.
 * 
 * @author IsmaelMB
 */
public class ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        System.out.println("Dime una frase: ");
        String frase=teclado.nextLine();
        System.out.println("Dime una otra frase: ");
        String frase2=teclado.nextLine();
        
        if (frase.equals(frase2)){
            System.out.println("Las frases son identicas");
        }
        else{
            if(frase.equalsIgnoreCase(frase2)){
                System.out.println("Son iguales pero hay diferencia entre mayúsculas y minúsculas");
            }
            else{
                System.out.println("las frases no son iguales");
            }
        }
            
    }
    
}
