/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicioscadenas;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * 1.	Crea un programa que pida una cadena de texto por teclado y luego 
 * muestre cada palabra de la cadena en una línea distinta.
 * 
 * @author IsmaelMB
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        System.out.println("Dime una frase: ");
        String frase=teclado.nextLine();
        String [] palabras = frase.split(" ");
        //System.out.println(Arrays.toString(palabras));
        for (int i=0;i<palabras.length;i++){
            System.out.println("\n"+palabras[i]);
        }
        
        
        
        
    }
    
}
